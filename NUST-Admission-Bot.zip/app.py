"""
NUST Admission Guide — Web UI
Run:  python app.py
Then open:  http://localhost:5000
"""

from __future__ import annotations

import ctypes
from ctypes import wintypes
import hashlib
import os
import time
from flask import Flask, render_template, request, jsonify

from rag import Retriever
from chatbot import ConversationState, answer_query

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")

app = Flask(__name__, template_folder=TEMPLATE_DIR)
app.config["TEMPLATES_AUTO_RELOAD"] = True
APP_START_TS = time.time()

# Load retriever once at startup
retriever = Retriever(data_path="nust_data.txt")

# One shared conversation state per server instance
# (fine for a single-user demo; extend with sessions for multi-user)
state = ConversationState()


def _dir_size_bytes(path: str) -> int:
    total = 0
    if not os.path.isdir(path):
        return 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            fp = os.path.join(root, name)
            try:
                total += os.path.getsize(fp)
            except OSError:
                continue
    return total


def _bytes_to_mb(n: int) -> float:
    return round(n / (1024 * 1024), 2)


def _process_memory_mb() -> tuple[float, float]:
    """Returns (rss_mb, peak_rss_mb) for current Python process."""
    if os.name == "nt":
        class PROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t),
                ("PrivateUsage", ctypes.c_size_t),
            ]

        counters = PROCESS_MEMORY_COUNTERS_EX()
        counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS_EX)
        get_current_process = ctypes.windll.kernel32.GetCurrentProcess
        get_current_process.restype = wintypes.HANDLE
        handle = get_current_process()

        cb = wintypes.DWORD(ctypes.sizeof(PROCESS_MEMORY_COUNTERS_EX))

        get_mem_info = ctypes.windll.psapi.GetProcessMemoryInfo
        get_mem_info.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
        get_mem_info.restype = wintypes.BOOL

        ok = get_mem_info(handle, ctypes.byref(counters), cb)

        # Fallback for environments where K32 export is required.
        if not ok:
            try:
                k32_get_mem_info = ctypes.windll.kernel32.K32GetProcessMemoryInfo
                k32_get_mem_info.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
                k32_get_mem_info.restype = wintypes.BOOL
                ok = k32_get_mem_info(handle, ctypes.byref(counters), cb)
            except Exception:
                ok = False

        if ok:
            return _bytes_to_mb(int(counters.WorkingSetSize)), _bytes_to_mb(int(counters.PeakWorkingSetSize))
        return 0.0, 0.0

    try:
        import resource  # Unix only
        ru = resource.getrusage(resource.RUSAGE_SELF)
        rss_kb = float(ru.ru_maxrss)
        # ru_maxrss is KB on Linux, bytes on macOS.
        peak_mb = round((rss_kb / 1024.0) if rss_kb > 10_000 else (rss_kb / (1024.0 * 1024.0)), 2)
        return peak_mb, peak_mb
    except Exception:
        return 0.0, 0.0


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/debug/ui")
def debug_ui():
    """Quick check to verify which template file Flask is serving."""
    tpl_path = os.path.join(TEMPLATE_DIR, "index.html")
    try:
        with open(tpl_path, "rb") as f:
            digest = hashlib.md5(f.read()).hexdigest()
    except OSError:
        digest = "unavailable"
    return jsonify({
        "template_dir": TEMPLATE_DIR,
        "template_file": tpl_path,
        "template_md5": digest,
    })


@app.route("/analytics")
def analytics():
    rss_mb, peak_mb = _process_memory_mb()
    kb_path = os.path.join(BASE_DIR, "nust_data.txt")
    cache_dir = os.path.join(BASE_DIR, ".cache")
    cache_index = os.path.join(cache_dir, "retrieval.index")

    try:
        docs_count = len(retriever.docs)
    except Exception:
        docs_count = 0

    try:
        topics_count = len(retriever.get_topics())
    except Exception:
        topics_count = 0

    qcache_size = len(getattr(retriever, "_qcache", {}))

    payload = {
        "timestamp": round(time.time(), 3),
        "uptime_sec": round(time.time() - APP_START_TS, 1),
        "constraints": {
            "target_ram_mb": 8192,
        },
        "memory": {
            "rss_mb": rss_mb,
            "peak_rss_mb": peak_mb,
        },
        "storage": {
            "kb_file_mb": _bytes_to_mb(os.path.getsize(kb_path)) if os.path.exists(kb_path) else 0.0,
            "cache_dir_mb": _bytes_to_mb(_dir_size_bytes(cache_dir)),
            "cache_index_exists": os.path.exists(cache_index),
        },
        "retriever": {
            "documents": docs_count,
            "topics": topics_count,
            "query_cache_size": qcache_size,
        },
    }
    return jsonify(payload)


@app.route("/chat", methods=["POST"])
def chat():
    data    = request.get_json(force=True)
    message = (data.get("message") or "").strip()

    if not message:
        return jsonify({"answer": "Please type a question.", "trust": "", "elapsed": 0})

    # Handle slash commands
    lower = message.lower()
    if lower == "/clear":
        state.history.clear()
        state.last_topic = ""
        return jsonify({"answer": "Conversation history cleared.", "trust": "", "elapsed": 0})

    if lower == "/topics":
        topics = retriever.get_topics()
        answer = "Topics I know about:\n" + "\n".join(f"• {t}" for t in topics)
        return jsonify({"answer": answer, "trust": "", "elapsed": 0})

    if lower == "/contact":
        answer = (
            "NUST Admission Contact\n"
            "• Email:   admissions@nust.edu.pk\n"
            "• Website: nust.edu.pk/admissions\n"
            "• Portal:  admissions.nust.edu.pk"
        )
        return jsonify({"answer": answer, "trust": "", "elapsed": 0})

    if lower == "/faq":
        answer = (
            "Common Questions\n"
            "• How do I apply? → Apply online at admissions.nust.edu.pk\n"
            "• What is NET?    → NUST Entry Test, held 4 times a year\n"
            "• Is there a quota? → No, purely merit-based\n"
            "• Negative marking? → No\n"
            "• Gap year allowed? → Yes\n"
            "• When do programs start? → Mostly September"
        )
        return jsonify({"answer": answer, "trust": "", "elapsed": 0})

    t0 = time.perf_counter()
    try:
        answer, trust = answer_query(retriever, message, state)
    except Exception as e:
        elapsed = time.perf_counter() - t0
        error_msg = f"[Server Error] {str(e)[:200]}"
        return jsonify({"answer": error_msg, "trust": "", "elapsed": round(elapsed, 1)})
    
    elapsed = time.perf_counter() - t0
    state.add(message, answer)
    return jsonify({"answer": answer, "trust": trust, "elapsed": round(elapsed, 1)})


@app.after_request
def add_no_cache_headers(response):
    # Prevent stale UI after frontend edits during local development.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


if __name__ == "__main__":
    print("\n  NUST Admission Guide")
    print("  Open → http://localhost:5000\n")
    app.run(debug=False, port=5000)