"""
NUST Admission Guide Chatbot
============================
Architecture:
  - RAG retrieves the most relevant chunks from nust_data.txt
    - Ollama (qwen2.5:3b-instruct) generates a natural, grounded answer from that context
  - Greetings / chitchat are handled directly without hitting RAG/LLM
  - Graceful fallback if Ollama is unavailable
"""

from __future__ import annotations

import re
import sys
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import requests

from rag import Retriever, SearchResult


# ─────────────────────────────────────────────
#  Terminal colours (no deps, ANSI)
# ─────────────────────────────────────────────
_COLOR = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

class C:
    RESET  = "\033[0m"  if _COLOR else ""
    BOLD   = "\033[1m"  if _COLOR else ""
    DIM    = "\033[2m"  if _COLOR else ""
    CYAN   = "\033[96m" if _COLOR else ""
    GREEN  = "\033[92m" if _COLOR else ""
    YELLOW = "\033[93m" if _COLOR else ""
    WHITE  = "\033[97m" if _COLOR else ""

def _print_bot(msg: str) -> None:
    print(f"\n{C.CYAN}{C.BOLD}Bot:{C.RESET}")
    for line in msg.splitlines():
        print(f"  {line}")
    print()

def _divider() -> None:
    print(f"{C.DIM}{'─' * 54}{C.RESET}")

def _header(msg: str) -> None:
    print(f"\n{C.BOLD}{msg}{C.RESET}")


# ─────────────────────────────────────────────
#  Greeting / chitchat — no LLM needed
# ─────────────────────────────────────────────
_GREETINGS = re.compile(
    r"^\s*(hi|hello|hey|salaam|salam|assalam|good\s*(morning|afternoon|evening)|"
    r"howdy|what'?s\s*up|sup)\s*[!?.]*\s*$",
    re.IGNORECASE,
)
_THANKS = re.compile(r"^\s*(thanks?|thank you|shukriya|jazak)\b", re.IGNORECASE)
_BYE   = re.compile(r"^\s*(bye|goodbye|exit|quit|see\s*you|later)\b", re.IGNORECASE)

_DECISION_INTENT = re.compile(
    r"(\bshould\s+i\b|\bwhich\s+is\s+better\b|\bwhat\s+should\s+i\s+choose\b|"
    r"\bnet\s+or\s+sat\b|\brecommend\b|\bconfused\b)",
    re.IGNORECASE,
)

_NET_RECHECK_INTENT = re.compile(
    r"\b(recheck|re-check|rechecking|re-checking|remark|re-mark|marking|totaling|totalling)\b",
    re.IGNORECASE,
)
_NET_APPLY_INTENT = re.compile(
    r"\b(net|nust\s*entry\s*test)\b.*\b(apply|application|register|registration|form)\b"
    r"|\b(apply|application|register|registration|form)\b.*\b(net|nust\s*entry\s*test)\b",
    re.IGNORECASE,
)
_ARCH_QUERY = re.compile(r"\b(architecture|design|industrial\s*design)\b", re.IGNORECASE)
_NET_QUERY = re.compile(r"\b(net|nust\s*entry\s*test)\b", re.IGNORECASE)
_NET_OVERVIEW_INTENT = re.compile(
    r"(\bwhat\s+is\s+the\s+net\b|\bnet\s+overview\b|\bhow\s+.*net\s+work|\bnet\s+schedule\b|\bseries\b)",
    re.IGNORECASE,
)

GREETING_REPLY = (
    "Hello! I'm the NUST Admission Guide. "
    "Ask me anything about programs, eligibility, NET/SAT, fees, or the application process."
)
THANKS_REPLY = "You're welcome! Feel free to ask if you have more questions."
BYE_REPLY    = "Goodbye! Best of luck with your NUST application!"


# ─────────────────────────────────────────────
#  Output sanitizer — prevent model drift hallucinations
# ─────────────────────────────────────────────
_HALLUCINATION_TRIGGERS = re.compile(
    r"(consider a scenario|consider three|consider two|consider \w+ test"
    r"|let's say|for example,? suppose|imagine that"
    r"|puzzle|logic puzzle|here are some clues"
    r"|student.*alice|student.*bob|alice.*bob|alice,? bob"
    r"|hypothetical|as an exercise|note that this is|in this case,? let"
    r"|in the context of|given the (above|following|context)"
    r"|\b(clue|hint)\s+\d"
    r"|applying for.*program|three test.takers|two students|four students"
    r"|\bNUSSTc\b|\bIBCS\b)",
    re.IGNORECASE,
)

_CHAT_ROLE_LINE = re.compile(r"^\s*(User|Assistant)\s*:\s*", re.IGNORECASE)


def _strip_prompt_echo(text: str) -> str:
    """Remove prompt scaffolding when the model echoes User/Assistant turns."""
    if not text:
        return text

    # If the model echoed conversation scaffolding, keep only content after
    # the last Assistant marker.
    if "Assistant:" in text and "User:" in text:
        tail = text.rsplit("Assistant:", 1)[-1].strip()
        if tail:
            text = tail

    lines = []
    for line in text.splitlines():
        if _CHAT_ROLE_LINE.match(line):
            continue
        lines.append(line)

    return "\n".join(lines).strip()

def _sanitize_output(text: str) -> str:
    """Truncate the response if the model starts hallucinating puzzles or examples."""
    if not text:
        return text

    text = _strip_prompt_echo(text)
    lines = text.splitlines()
    clean: List[str] = []
    for line in lines:
        if _HALLUCINATION_TRIGGERS.search(line):
            break
        clean.append(line)
    result = "\n".join(clean).strip()

    result = re.sub(r"\n{3,}", "\n\n", result)
    return result or text


OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen2.5:3b-instruct"

SYSTEM_PROMPT = (
    "You are a NUST Admission Guide. Answer ONLY from the context provided.\n"
    "Rules (follow strictly):\n"
    "1. Use ONLY facts from the context. Never add outside knowledge.\n"
    "2. Be friendly and natural. Prefer clear structure with short headings and bullets or numbered steps when helpful.\n"
    "3. If the user asks a how-to or process question, provide step-by-step instructions with one step per line.\n"
    "4. STOP writing after the answer is complete. Do NOT add puzzles, hypotheticals, or unrelated commentary.\n"
    "5. Keep it concise but complete (typically 6-12 lines when details are needed).\n"
    "6. Preserve readability with line breaks; do not cram multiple steps into one sentence.\n"
    "7. If the context does not answer the question, say: "
    "I don't have that detail — please visit nust.edu.pk or email admissions@nust.edu.pk\n"
    "8. Do not repeat the question.\n"
)

def _build_prompt(context: str, conversation: str, question: str) -> str:
    return (
        f"{SYSTEM_PROMPT}\n"
        f"Context:\n{context}\n\n"
        f"{conversation}"
        f"User: {question}\n"
        f"Assistant:"
    )

def _call_ollama(prompt: str, timeout: int = 60) -> Optional[str]:
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "num_predict": 320,
                    "top_p": 0.9,
                    "repeat_penalty": 1.3,
                    "stop": ["\nUser:", "\nAssistant:"],
                },
            },
            timeout=timeout,
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
        text = _sanitize_output(text)
        return text or None
    except requests.exceptions.ConnectionError:
        return None
    except Exception:
        return None


# ─────────────────────────────────────────────
#  Context builder from RAG results
# ─────────────────────────────────────────────
def _build_context(results: List[SearchResult], max_chars: int = 2000) -> str:
    parts: List[str] = []
    total = 0
    for r in results:
        lines = []
        for line in r.text.splitlines():
            s = line.strip()
            if s.startswith("[TOPIC:") or s.lower().startswith("source:"):
                continue
            if s:
                lines.append(s)
        chunk = "\n".join(lines)
        if total + len(chunk) > max_chars:
            chunk = chunk[: max_chars - total]
        parts.append(f"[{r.topic}]\n{chunk}")
        total += len(chunk)
        if total >= max_chars:
            break
    return "\n\n".join(parts)


def _extractive_answer(results: List[SearchResult], max_lines: int = 6) -> str:
    """Fallback: return concise factual lines from top retrieved chunks."""
    lines: List[str] = []
    for r in results[:2]:
        for line in r.text.splitlines():
            s = line.strip()
            if not s:
                continue
            if s.startswith("[TOPIC:") or s.lower().startswith("source:") or s.lower().startswith("topic:"):
                continue
            lines.append(s)
            if len(lines) >= max_lines:
                break
        if len(lines) >= max_lines:
            break
    if not lines:
        return NO_DETAIL_MSG
    return "\n".join(lines)


def _intent_bucket(query: str) -> str:
    q = (query or "").strip()
    if _NET_RECHECK_INTENT.search(q):
        return "net_rechecking"
    if _NET_APPLY_INTENT.search(q):
        return "net_application"
    return "general"


def _should_exclude_architecture_topic(query: str) -> bool:
    q = (query or "")
    return bool(_NET_QUERY.search(q)) and not bool(_ARCH_QUERY.search(q))


def _is_net_overview_query(query: str) -> bool:
    q = (query or "")
    return bool(_NET_QUERY.search(q)) and bool(_NET_OVERVIEW_INTENT.search(q))


def _lines_without_meta(text: str) -> List[str]:
    out: List[str] = []
    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            continue
        if s.startswith("[TOPIC:") or s.lower().startswith("source:"):
            continue
        out.append(s)
    return out


def _build_net_overview_answer(results: List[SearchResult]) -> Optional[str]:
    by_topic = {r.topic.strip().lower(): r for r in results}
    ov = by_topic.get("net overview")
    sch = by_topic.get("net schedule 2026")

    if not ov and not sch:
        return None

    out: List[str] = ["NUST Entry Test (NET) works as follows:", ""]

    if ov:
        lines = _lines_without_meta(ov.text)
        for s in lines:
            sl = s.lower()
            if "conducted multiple times" in sl:
                out.append("- Candidates can attempt the test multiple times within a year.")
            elif "best score" in sl:
                out.append("- The best score among all attempts in one admission cycle is considered for admission.")
            elif "valid for one admission cycle" in sl:
                out.append("- NET score remains valid for one admission cycle only.")

    if sch:
        series: List[str] = []
        lines = _lines_without_meta(sch.text)
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.lower().startswith("series"):
                label = line.rstrip(":")
                detail = ""
                j = i + 1
                while j < len(lines):
                    cand = lines[j]
                    if cand.lower().startswith("series"):
                        break
                    if cand.startswith("-"):
                        detail = cand.lstrip("- ").strip()
                        break
                    j += 1
                if detail:
                    series.append(f"- {label}: {detail}")
            i += 1

        if series:
            out.append("- There are four NET series each academic year:")
            out.extend(series)

    # Ensure minimum useful structure before returning curated response.
    if sum(1 for l in out if l.startswith("- ")) < 3:
        return None
    return "\n".join(out)


def _is_decision_query(query: str) -> bool:
    return bool(_DECISION_INTENT.search(query or ""))


def _normalize_option_name(name: str) -> str:
    n = (name or "").strip().lower()
    if n in {"net", "nust entry test", "entry test"}:
        return "NET"
    if n in {"sat", "sat i", "sat-1"}:
        return "SAT"
    if n in {"act", "act/sat", "sat/act"}:
        return "ACT/SAT"
    return name.strip().upper() if name.strip() else ""


def _extract_options_from_query(query: str) -> List[str]:
    q = (query or "").strip()
    ql = q.lower()

    if "net" in ql and "sat" in ql and "act" in ql:
        return ["NET", "ACT/SAT"]
    if "net" in ql and "sat" in ql:
        return ["NET", "SAT"]
    if "net" in ql and "act" in ql:
        return ["NET", "ACT"]

    m = re.search(r"\b([a-zA-Z/\- ]{2,25})\s+or\s+([a-zA-Z/\- ]{2,25})\b", q, re.IGNORECASE)
    if m:
        a = _normalize_option_name(m.group(1))
        b = _normalize_option_name(m.group(2))
        if a and b and a != b:
            return [a, b]

    return []


def _option_keywords(option: str) -> List[str]:
    o = option.lower()
    if o == "net":
        return ["net", "entry test", "best score", "multiple times"]
    if o == "sat":
        return ["sat", "code: sat", "minimum 550", "valid 2 years"]
    if o in {"act", "act/sat"}:
        return ["act", "sat", "limited seats", "minimum 25", "codes:"]
    return [o]


def _collect_option_points(results: List[SearchResult], option: str) -> Tuple[List[str], List[str]]:
    pros: List[str] = []
    cons: List[str] = []
    kws = _option_keywords(option)

    for r in results[:5]:
        for raw in r.text.splitlines():
            line = raw.strip(" -\t")
            if not line:
                continue
            low = line.lower()
            if low.startswith("[topic:") or low.startswith("source:"):
                continue
            if not any(k in low for k in kws):
                continue

            is_constraint = any(w in low for w in [
                "minimum", "required", "deadline", "limited", "fee", "non-refundable", "condition"
            ])

            if is_constraint:
                if line not in cons and len(cons) < 3:
                    cons.append(line)
            else:
                if line not in pros and len(pros) < 3:
                    pros.append(line)

            if len(pros) >= 3 and len(cons) >= 3:
                break
        if len(pros) >= 3 and len(cons) >= 3:
            break

    return pros, cons


def _recommend_option(options: List[str], option_points: List[Tuple[List[str], List[str]]], query: str) -> Tuple[str, List[str]]:
    # Score by evidence balance, then apply light context hints from user wording.
    scores: List[int] = []
    for pros, cons in option_points:
        scores.append(len(pros) * 2 - len(cons))

    ql = (query or "").lower()
    for i, opt in enumerate(options):
        ol = opt.lower()
        if "international" in ql and ol in {"sat", "act", "act/sat"}:
            scores[i] += 1
        if any(w in ql for w in ["best score", "multiple attempt", "retake", "again"]) and ol == "net":
            scores[i] += 1

    best_i = max(range(len(options)), key=lambda i: scores[i])
    best = options[best_i]

    rationale = [
        "Reliability: based on explicit policy points retrieved from NUST sources.",
        "Success chances: favors the route with stronger score/attempt advantages in the retrieved data.",
        "Flexibility: weighs retake windows, validity period, and available routes from context.",
        "Student context: adjusted to the intent in your question when relevant.",
    ]
    return best, rationale


def _build_decision_response(query: str, results: List[SearchResult]) -> str:
    options = _extract_options_from_query(query)
    if len(options) < 2:
        return (
            "[Decision Guide]\n\n"
            "I can help, but I need two options to compare.\n"
            "Please tell me what you're deciding between (for example: NET vs SAT, or NET vs ACT)."
        )

    option_points = [_collect_option_points(results, opt) for opt in options]
    if any(len(pros) + len(cons) == 0 for pros, cons in option_points):
        return (
            "[Decision Guide]\n\n"
            "I need one clarification before recommending: which exact options should I compare for your case?"
        )

    recommended, rationale = _recommend_option(options, option_points, query)

    out: List[str] = ["[Decision Guide]", ""]
    for idx, opt in enumerate(options):
        pros, cons = option_points[idx]
        out.append(f"Option {idx + 1}: {opt}")
        out.append("")
        out.append("- Pros:")
        for p in pros[:3]:
            out.append(f"  - {p}")
        if not pros:
            out.append("  - No strong upside found in retrieved context.")
        out.append("- Cons:")
        for c in cons[:3]:
            out.append(f"  - {c}")
        if not cons:
            out.append("  - No major limitation explicitly stated in retrieved context.")
        out.append("")

    out.append("Recommendation:")
    out.append(f"- Recommended option: {recommended}")
    out.append("- Reasoning:")
    for line in rationale:
        out.append(f"  - {line}")

    return "\n".join(out).strip()


# ─────────────────────────────────────────────
#  Conversation state
# ─────────────────────────────────────────────
@dataclass
class ConversationState:
    history: List[Tuple[str, str]] = field(default_factory=list)
    last_topic: str = ""

    def add(self, user: str, bot: str) -> None:
        self.history.append((user, bot))
        if len(self.history) > 6:
            self.history.pop(0)

    def recent_context(self) -> str:
        if not self.history:
            return ""
        recent = self.history[-2:]
        lines = []
        for u, b in recent:
            lines.append(f"User: {u}")
            lines.append(f"Assistant: {b}")
        return "\n".join(lines) + "\n"


# ─────────────────────────────────────────────
#  Core answer pipeline
# ─────────────────────────────────────────────
OLLAMA_DOWN_MSG = (
    "I couldn't connect to the local AI model. "
    "Make sure Ollama is running:\n"
    "  1. Open a terminal and run: ollama serve\n"
    "  2. Then run: ollama pull qwen2.5:3b-instruct\n"
    "  3. Restart this chatbot."
)

NO_DETAIL_MSG = "I don't have that detail — please visit nust.edu.pk or email admissions@nust.edu.pk"

def answer_query(
    retriever: Retriever,
    user_query: str,
    state: ConversationState,
) -> Tuple[str, str]:
    """Returns (answer, trust_footer)."""

    # Chitchat shortcuts — no RAG or LLM needed
    if _GREETINGS.match(user_query):
        return GREETING_REPLY, ""
    if _THANKS.match(user_query):
        return THANKS_REPLY, ""

    intent = _intent_bucket(user_query)
    decision_mode = _is_decision_query(user_query)

    # RAG retrieval — prepend last topic to help with follow-up questions.
    # If that weakens retrieval, retry with the raw query.
    search_q = f"{state.last_topic} {user_query}".strip() if state.last_topic else user_query
    if intent == "net_rechecking":
        search_q = f"NET RECHECKING {search_q}".strip()
    elif intent == "net_application":
        search_q = f"APPLICATION PROCESS NET REGISTRATION {search_q}".strip()

    results = retriever.search(search_q, k=7)
    if state.last_topic:
        fresh_results = retriever.search(user_query, k=7)
        if fresh_results and (not results or fresh_results[0].score >= results[0].score + 0.05):
            results = fresh_results

    # Keep architecture-specific NET composition out of general NET answers.
    if _should_exclude_architecture_topic(user_query):
        filtered = [r for r in results if r.topic.strip().lower() != "net architecture"]
        if filtered:
            results = filtered

    # Intent guard: avoid mixing NET rechecking with regular NET application.
    if intent == "net_application":
        filtered = [r for r in results if r.topic.strip().lower() != "net rechecking"]
        if filtered:
            results = filtered
    elif intent == "net_rechecking":
        filtered = [r for r in results if r.topic.strip().lower() == "net rechecking"]
        if filtered:
            results = filtered

    if not results:
        return (NO_DETAIL_MSG, "Source: NUST KB | Confidence: Low")

    if _is_net_overview_query(user_query):
        extra = retriever.search("NET OVERVIEW NET SCHEDULE 2026", k=6)
        merged = {r.topic.strip().lower(): r for r in results}
        for r in extra:
            merged[r.topic.strip().lower()] = r
        curated = _build_net_overview_answer(list(merged.values()))
        if curated:
            top = results[0]
            trust = (
                f"Source: {top.source} | Topic: {top.topic} | "
                f"Confidence: {top.confidence} ({top.score:.2f})"
            )
            state.last_topic = top.topic
            return curated, trust

    if decision_mode:
        top = results[0]
        decision_answer = _build_decision_response(user_query, results)
        trust = (
            f"Source: {top.source} | Topic: {top.topic} | "
            f"Confidence: {top.confidence} ({top.score:.2f})"
        )
        state.last_topic = top.topic
        return decision_answer, trust

    top = results[0]
    context = _build_context(results)
    prompt  = _build_prompt(context, state.recent_context(), user_query)
    answer  = _call_ollama(prompt)

    if answer is None:
        return OLLAMA_DOWN_MSG, ""

    # Recovery path: if model still declines despite retrieved evidence,
    # answer directly from retrieved lines instead of returning "no detail".
    if re.match(r"^\s*I don't have that detail", answer, re.IGNORECASE):
        answer = _extractive_answer(results)

    state.last_topic = top.topic
    trust = (
        f"Source: {top.source} | Topic: {top.topic} | "
        f"Confidence: {top.confidence} ({top.score:.2f})"
    )
    return answer, trust


# ─────────────────────────────────────────────
#  Command handlers
# ─────────────────────────────────────────────
COMMANDS = {
    "/help":    "Show this menu",
    "/topics":  "Browse all knowledge-base topics",
    "/faq":     "Frequently asked questions",
    "/contact": "NUST admission contact info",
    "/history": "Show last 3 Q&A pairs",
    "/clear":   "Clear conversation history",
    "/exit":    "Exit the chatbot",
}

def show_help() -> None:
    _header("Available Commands")
    for cmd, desc in COMMANDS.items():
        print(f"  {C.GREEN}{cmd:<12}{C.RESET} {desc}")
    print()

def show_faq() -> None:
    faqs = [
        ("How do I apply to NUST?",          "Apply online via the portal at admissions.nust.edu.pk."),
        ("What is the NET?",                  "NUST Entry Test — the primary admission test, held 4 times a year."),
        ("Is there a quota system?",          "No, NUST uses a purely merit-based system."),
        ("Is there negative marking in NET?", "No negative marking in NET."),
        ("Can I apply after a gap year?",     "Yes, gap year students are eligible."),
        ("When do programs start?",           "Most programs start in September."),
        ("What is the application fee?",      "Rs. 5,000 for NET/national; Rs. 10,000 for international."),
    ]
    _header("Frequently Asked Questions")
    for q, a in faqs:
        print(f"  {C.YELLOW}Q:{C.RESET} {q}")
        print(f"  {C.GREEN}A:{C.RESET} {a}\n")

def show_contact() -> None:
    _header("NUST Admission Contact")
    print(f"  {C.CYAN}Email  :{C.RESET}  admissions@nust.edu.pk")
    print(f"  {C.CYAN}Website:{C.RESET}  nust.edu.pk/admissions")
    print(f"  {C.CYAN}Portal :{C.RESET}  admissions.nust.edu.pk")
    print()

def show_history(state: ConversationState) -> None:
    if not state.history:
        _print_bot("No conversation history yet.")
        return
    _header("Recent Conversation")
    for u, b in state.history[-3:]:
        print(f"  {C.YELLOW}You:{C.RESET} {u}")
        preview = b[:140] + ("…" if len(b) > 140 else "")
        print(f"  {C.CYAN}Bot:{C.RESET} {preview}\n")


# ─────────────────────────────────────────────
#  Startup banner
# ─────────────────────────────────────────────
def print_banner(startup_s: float) -> None:
    print()
    print(f"{C.CYAN}{C.BOLD}{'═' * 54}{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}   NUST Admission Guide — Offline AI Chatbot{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}{'═' * 54}{C.RESET}")
    print(f"  Knowledge base loaded in {C.GREEN}{startup_s:.2f}s{C.RESET}")
    print(f"  Type {C.GREEN}/help{C.RESET} for commands or just ask a question.\n")


# ─────────────────────────────────────────────
#  Main loop
# ─────────────────────────────────────────────
def main() -> None:
    t0 = time.perf_counter()
    retriever = Retriever(data_path="nust_data.txt")
    startup_s = time.perf_counter() - t0

    state = ConversationState()
    print_banner(startup_s)

    while True:
        try:
            raw = input(f"{C.WHITE}{C.BOLD}You:{C.RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            _print_bot("Goodbye! Good luck with your application.")
            break

        if not raw:
            print(f"  {C.DIM}Type a question or /help{C.RESET}")
            continue

        lower = raw.lower()

        # Commands
        if lower in ("/exit", "/quit") or _BYE.match(raw):
            _print_bot(BYE_REPLY)
            break
        if lower == "/help":
            show_help(); continue
        if lower == "/topics":
            _header("Topics in Knowledge Base")
            for t in retriever.get_topics():
                print(f"  {C.GREEN}·{C.RESET} {t}")
            print(); continue
        if lower == "/faq":
            show_faq(); continue
        if lower == "/contact":
            show_contact(); continue
        if lower == "/history":
            show_history(state); continue
        if lower == "/clear":
            state.history.clear()
            state.last_topic = ""
            _print_bot("Conversation history cleared.")
            continue

        # Answer
        print(f"  {C.DIM}Thinking…{C.RESET}", end="\r", flush=True)
        t_start = time.perf_counter()
        answer, trust = answer_query(retriever, raw, state)
        elapsed = time.perf_counter() - t_start

        state.add(raw, answer)
        _print_bot(answer)

        if trust:
            _divider()
            print(f"  {C.DIM}{trust}  |  {elapsed:.1f}s{C.RESET}")
            _divider()
            print()


if __name__ == "__main__":
    main()