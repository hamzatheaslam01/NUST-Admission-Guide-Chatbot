"""
RAG (Retrieval-Augmented Generation) engine for NUST Admission Guide
====================================================================
Design decisions:
  - IndexFlatIP on normalised embeddings → cosine similarity in [−1, 1] mapped to [0, 1].
  - Hybrid score: 70 % semantic + 30 % lexical + 12 % topic boost.
  - LRU cache for query embeddings (64 slots) — avoids re-encoding repeated queries.
  - Disk-cached FAISS index with MD5 fingerprint; rebuilt automatically when data changes.
  - Confidence thresholds tuned for CPU-only demo reliability.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from collections import OrderedDict
from dataclasses import dataclass
from typing import List, Optional

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


@dataclass
class SearchResult:
    text: str
    topic: str
    source: str
    score: float
    confidence: str  # "High" | "Medium" | "Low"


class Retriever:
    # Confidence thresholds — tuned for this knowledge base size / query style
    HIGH_THRESH   = 0.62
    MEDIUM_THRESH = 0.42

    def __init__(
        self,
        data_path: str = "nust_data.txt",
        model_name: str = "all-MiniLM-L6-v2",
        cache_dir: str = ".cache",
    ) -> None:
        self.data_path  = data_path
        self.model_name = model_name
        self.cache_dir  = cache_dir
        self.meta_path  = os.path.join(cache_dir, "retrieval_meta.json")
        self.index_path = os.path.join(cache_dir, "retrieval.index")

        self.model = self._load_model()
        self.docs  = self._load_docs()

        # Pre-compute metadata lists (one pass over docs)
        self.doc_topics   = [self._topic_from_doc(d)  for d in self.docs]
        self.doc_sources  = [self._source_from_doc(d) for d in self.docs]
        self.doc_tokens   = [set(self._tokenize(d))   for d in self.docs]
        self.topic_tokens = [set(self._tokenize(t))   for t in self.doc_topics]

        self._qcache: OrderedDict[str, np.ndarray] = OrderedDict()
        self._qcache_size = 128

        self.index = self._load_or_build_index()

    # ──────────────────────────────────────────
    #  Model loading
    # ──────────────────────────────────────────
    def _load_model(self) -> SentenceTransformer:
        try:
            return SentenceTransformer(self.model_name, local_files_only=True)
        except OSError as exc:
            raise RuntimeError(
                "Embedding model not found locally. "
                "Run once with internet to download sentence-transformers/all-MiniLM-L6-v2, "
                "then use offline."
            ) from exc

    # ──────────────────────────────────────────
    #  Data loading
    # ──────────────────────────────────────────
    def _load_docs(self) -> List[str]:
        with open(self.data_path, "r", encoding="utf-8") as f:
            raw = f.read()
        docs = [d.strip() for d in raw.split("---") if d.strip()]
        if not docs:
            raise ValueError(f"No documents found in {self.data_path}")
        return docs

    def _data_fingerprint(self) -> str:
        with open(self.data_path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()

    # ──────────────────────────────────────────
    #  FAISS index (cached)
    # ──────────────────────────────────────────
    def _build_index(self) -> faiss.Index:
        embeddings = self.model.encode(self.docs, normalize_embeddings=True, show_progress_bar=False)
        arr = np.array(embeddings, dtype="float32")
        index = faiss.IndexFlatIP(arr.shape[1])
        index.add(arr)
        return index

    def _cache_valid(self) -> bool:
        if not (os.path.exists(self.meta_path) and os.path.exists(self.index_path)):
            return False
        try:
            with open(self.meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except (OSError, json.JSONDecodeError):
            return False
        return (
            meta.get("fingerprint") == self._data_fingerprint()
            and meta.get("model")    == self.model_name
            and meta.get("count")    == len(self.docs)
            and meta.get("itype")    == "FlatIP"
        )

    def _load_or_build_index(self) -> faiss.Index:
        os.makedirs(self.cache_dir, exist_ok=True)
        if self._cache_valid():
            return faiss.read_index(self.index_path)
        index = self._build_index()
        faiss.write_index(index, self.index_path)
        with open(self.meta_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "fingerprint": self._data_fingerprint(),
                    "model":       self.model_name,
                    "count":       len(self.docs),
                    "itype":       "FlatIP",
                },
                f,
            )
        return index

    # ──────────────────────────────────────────
    #  Metadata helpers
    # ──────────────────────────────────────────
    def _extract_field(self, doc: str, prefix: str, fallback: str) -> str:
        for line in doc.splitlines():
            stripped = line.strip()
            if stripped.lower().startswith(prefix.lower()):
                parts = stripped.split(":", 1)
                if len(parts) == 2 and parts[1].strip():
                    return parts[1].strip()
        return fallback

    def _topic_from_doc(self, doc: str) -> str:
        m = re.search(r"\[TOPIC:\s*(.*?)\]", doc, flags=re.IGNORECASE)
        if m:
            return m.group(1).strip()
        return self._extract_field(doc, "Topic", "General")

    def _source_from_doc(self, doc: str) -> str:
        return self._extract_field(doc, "Source", "NUST Knowledge Base")

    # ──────────────────────────────────────────
    #  Tokenisation
    # ──────────────────────────────────────────
    _STOPWORDS = frozenset({
        "the", "is", "are", "a", "an", "in", "on", "of", "to", "for",
        "and", "how", "what", "where", "when", "why", "who", "i", "am",
        "my", "me", "we", "you", "nust", "can", "do", "does", "be",
        "was", "with", "at", "by", "this", "that",
    })

    def _normalize(self, token: str) -> str:
        t = token.lower()
        if len(t) > 4 and t.endswith("es"):
            return t[:-2]
        if len(t) > 3 and t.endswith("s"):
            return t[:-1]
        return t

    def _tokenize(self, text: str) -> List[str]:
        raw = re.findall(r"[a-zA-Z0-9]+", text.lower())
        out: List[str] = []
        for tok in raw:
            norm = self._normalize(tok)
            if len(norm) <= 2 or norm in self._STOPWORDS:
                continue
            out.append(norm)
        return out

    # ──────────────────────────────────────────
    #  Query embedding (LRU cached)
    # ──────────────────────────────────────────
    def _query_emb(self, query: str) -> np.ndarray:
        key = query.strip().lower()
        if key in self._qcache:
            self._qcache.move_to_end(key)
            return self._qcache[key]
        emb = self.model.encode([query], normalize_embeddings=True)
        arr = np.array(emb, dtype="float32")
        self._qcache[key] = arr
        if len(self._qcache) > self._qcache_size:
            self._qcache.popitem(last=False)
        return arr

    # ──────────────────────────────────────────
    #  Scoring helpers
    # ──────────────────────────────────────────
    def _lexical(self, query_tokens: set, doc_tokens: set) -> float:
        if not query_tokens:
            return 0.0
        exact = query_tokens & doc_tokens
        soft = sum(
            1 for q in query_tokens
            if q not in exact and any(q in d or d in q for d in doc_tokens)
        )
        return (len(exact) + 0.7 * soft) / len(query_tokens)

    def _topic_boost(self, query_tokens: set, topic_tokens: set) -> float:
        if query_tokens and topic_tokens and query_tokens & topic_tokens:
            return 0.12
        return 0.0

    def _confidence(self, score: float) -> str:
        if score >= self.HIGH_THRESH:
            return "High"
        if score >= self.MEDIUM_THRESH:
            return "Medium"
        return "Low"

    # ──────────────────────────────────────────
    #  Public API
    # ──────────────────────────────────────────
    def search(self, query: str, k: int = 5) -> List[SearchResult]:
        if not query.strip() or not self.docs:
            return []

        k          = max(1, min(k, len(self.docs)))
        cand_k     = min(max(k * 4, 10), len(self.docs))
        q_emb      = self._query_emb(query)
        q_tokens   = set(self._tokenize(query))

        sims, idxs = self.index.search(q_emb, cand_k)

        results: List[SearchResult] = []
        for sim, idx in zip(sims[0], idxs[0]):
            i        = int(idx)
            semantic = (float(sim) + 1.0) / 2.0          # map [−1,1] → [0,1]
            lexical  = self._lexical(q_tokens, self.doc_tokens[i])
            boost    = self._topic_boost(q_tokens, self.topic_tokens[i])
            score    = min(1.0, 0.70 * semantic + 0.30 * lexical + boost)

            results.append(SearchResult(
                text       = self.docs[i],
                topic      = self.doc_topics[i],
                source     = self.doc_sources[i],
                score      = round(score, 3),
                confidence = self._confidence(score),
            ))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:k]

    def get_topics(self) -> List[str]:
        return sorted({self._topic_from_doc(d) for d in self.docs})